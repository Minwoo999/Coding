int euclid_1(int a, int b);
int euclid_2(int a, int b);
